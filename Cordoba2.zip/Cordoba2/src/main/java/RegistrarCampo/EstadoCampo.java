package RegistrarCampo;

public class EstadoCampo extends Campo {

    private Object nombreEstdCampo;

    public EstadoCampo() {
    }

    public void ConsultarEstdCampo() {
    }
}
