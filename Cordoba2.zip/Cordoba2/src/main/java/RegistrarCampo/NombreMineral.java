package RegistrarCampo;

public enum NombreMineral {

    Agua, Mineral, Tierra
}
