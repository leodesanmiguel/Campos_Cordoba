package RegistrarCampo;

public class Cultivo {

    private String NombreCultivo;

    public Cultivo() {
    }

    public Cultivo(String NombreCultivo) {
        this.NombreCultivo = NombreCultivo;
       
    }

     public String getNombreCultivo() {
        return NombreCultivo;
    }    

     public void setNombreCultivo(String NombreCultivo) {
        this.NombreCultivo = NombreCultivo;
    }
    

}
