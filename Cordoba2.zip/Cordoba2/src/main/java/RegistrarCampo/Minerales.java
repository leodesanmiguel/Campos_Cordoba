package RegistrarCampo;

public class Minerales {

    private Object PorcentMinaral;

    private Object NombreMineral;

    public Minerales() {
    }

    public void RegistrarPorcentaje() {
    }
}
