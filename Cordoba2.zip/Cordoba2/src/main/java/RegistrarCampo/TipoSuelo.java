package RegistrarCampo;

public class TipoSuelo {

    private String NroSuelo;

    public TipoSuelo(String NroSuelo_) {
        this.NroSuelo = NroSuelo_;
    }
    
    public String getNroSuelo() {
        return NroSuelo;
    }
    
    public void setNroSuelo(String NroSuelo_) {
        this.NroSuelo = NroSuelo_;
    }
            
    public void AsignarTipoSuelo() {
    }
}
