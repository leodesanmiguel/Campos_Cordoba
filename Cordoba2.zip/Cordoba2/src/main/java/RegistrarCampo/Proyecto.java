package RegistrarCampo;

public class Proyecto extends MomentoProyecto {

    private Object IdProyecto;

    public Proyecto() {
    }

    public void ActivarNuevoProyecto() {
    }
}
