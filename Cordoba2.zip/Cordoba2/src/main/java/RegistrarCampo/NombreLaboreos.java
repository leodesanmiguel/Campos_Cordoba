package RegistrarCampo;

public enum NombreLaboreos {

    Arar, Rastrillar, Sembrar, Escardillar, Cosechar, Rolar, Fumigar, Abandonar
}
