package RegistrarCampo;

public class Laboreos {

    private Object NombreLaboreo;

    private Object FechaInicio;

    private Object FechaFin;

    public Laboreos() {
    }

    public void AplicarLaboreo() {
    }
}
