package RegistrarCampo;

public enum NombreCultivo {

    Soja, Mani, Girasol, otro
}
