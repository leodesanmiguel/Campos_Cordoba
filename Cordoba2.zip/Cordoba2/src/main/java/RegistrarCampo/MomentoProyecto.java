package RegistrarCampo;

public class MomentoProyecto {

    private Object NombreMmtoProyecto;

    public MomentoProyecto() {
    }
}
